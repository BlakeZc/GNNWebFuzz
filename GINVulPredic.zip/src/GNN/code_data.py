import os
import os.path as osp
import numpy as np
import pandas as pd
import torch
import pickle
import re
from ast import literal_eval
# from rdkit import RDLogger
from torch_geometric.data import Data, Dataset

# from src.word2vec.word2vec import EmbeddingModel, vocab_size, EMBEDDING_SIZE

# def loadWord2vecModel():
#     model = EmbeddingModel(vocab_size, EMBEDDING_SIZE)
#     model.load_state_dict(torch.load("model/embedding-{}.th".format(EMBEDDING_SIZE)))
#     embedding_weights = model.input_embedding()
#     return embedding_weights

# def word2vec(word):
#     with open('model/word2idx.pkl', 'rb') as f:
#         word2idx = pickle.load(f)
#         f.close()
    
#     embedding_weights = loadWord2vecModel()
#     wordVec = embedding_weights[word2idx[word]]
#     return wordVec

# RDLogger.DisableLog('rdApp.*')


class MyDataset(Dataset):

    def __init__(self, root, taskName = None):
        # self.url = 'https://dgl-data.s3-accelerate.amazonaws.com/dataset/OGB-LSC/pcqm4m_kddcup2021.zip'
        super(MyDataset, self).__init__(root)
        self.taskName = taskName
        if taskName:
            filepath = osp.join(root, taskName + '_idx.th')
        else:
            filepath = osp.join(root, 'raw_dir/cwe_79_idx.th')
        
        self.dataset = torch.load(filepath)
        # data_df = pd.read_csv(filepath)
        # self.x = data_df['x']
        # self.edge_index = data_df['edge_index']
        # self.edge_attr = data_df['edge_attr']
        # self.y = data_df['y']
        # self.num_nodes = data_df['num_nodes']

    @property
    def raw_dir(self) -> str:
        return osp.join(self.root, 'raw_dir')
    
    @property
    def raw_file_names(self):
        return 'cwe-79.csv'

    # def download(self):
    #     path = download_url(self.url, self.root)
    #     extract_zip(path, self.root)
    #     os.unlink(path)
    #     shutil.move(osp.join(self.root, 'pcqm4m_kddcup2021/raw/data.csv.gz'), osp.join(self.root, 'raw/data.csv.gz'))

    def len(self):
        return len(self.dataset)

    def get(self, idx):
        data = self.dataset[idx]
        x = data['x']
        edge_index = data['edge_index']
        edge_attr = data['edge_attr']
        y = data['y']
        num_nodes = data['num_nodes']
        data = Data(x, edge_index, edge_attr, y, num_nodes=num_nodes)
        return data

    # def get(self, idx):
    #     x, edge_index, edge_attr, y, num_nodes = self.x[idx], self.edge_index[idx], self.edge_attr[idx], self.y[idx], self.num_nodes[idx]
    #     edge_index = literal_eval(edge_index)
    #     edge_attr = literal_eval(edge_attr)

    #     # 处理x对应的字符串至词向量序列
    #     nodeList = x
    #     nodeList = literal_eval(nodeList)
    #     nodeVecList = []
    #     for nodeCode in nodeList:
    #         nodeCode = nodeCode.strip('"')
    #         nodeCode = re.split(r"\\l|[\s]+", nodeCode)
    #         nodeCode = list(filter(None, nodeCode))
    #         wordList = []
    #         for sentence in nodeCode:
    #             sentenceWordList = re.split(r"(['{}():[\]<>])", sentence)
    #             wordList += sentenceWordList
    #         wordList = list(filter(None, wordList))
    #         VecList = []
    #         for word in wordList:
    #             wordVec = word2vec(word)
    #             VecList.append(wordVec)
    #         # 对VecList进行处理（先转成一维，再进行补充和截取）
    #         lenVecList = len(VecList)
    #         zeroList = [0] * 30
    #         if lenVecList < 300:
    #             VecList += (300 - lenVecList) * [zeroList]
    #         else:
    #             VecList = VecList[0:300]
    #         nodeVecList += VecList
    #     x = torch.tensor(np.array(nodeVecList))
    #     x = x.reshape(len(nodeList), 9000)

    #     # 将edge_index\edge_attr\y\num_nodes转换成矩阵
    #     edge_index = torch.tensor(edge_index).T
    #     edge_attr = torch.tensor(edge_attr).reshape(len(self.edge_attr), 1)
    #     y = torch.Tensor([y])
    #     num_nodes = int(num_nodes)
        
    #     data = Data(x, edge_index, edge_attr, y, num_nodes=num_nodes)
    #     return data

    # def get_idx_split(self):
    #     split_dict = replace_numpy_with_torchtensor(torch.load(osp.join(self.root, 'pcqm4m_kddcup2021/split_dict.pt')))
    #     return split_dict

class Evaluator:
    def __init__(self):
        '''
            Evaluator for the dataset
            Metric is Mean Absolute Error
        '''
        pass 
    
    # # 基于mae进行评估
    # def eval(self, input_dict):
    #     '''
    #         y_true: numpy.ndarray or torch.Tensor of shape (num_graphs,)
    #         y_pred: numpy.ndarray or torch.Tensor of shape (num_graphs,)
    #         y_true and y_pred need to be of the same type (either numpy.ndarray or torch.Tensor)
    #     '''
    #     assert('y_pred' in input_dict)
    #     assert('y_true' in input_dict)

    #     y_pred, y_true = input_dict['y_pred'], input_dict['y_true']

    #     assert((isinstance(y_true, np.ndarray) and isinstance(y_pred, np.ndarray))
    #             or
    #             (isinstance(y_true, torch.Tensor) and isinstance(y_pred, torch.Tensor)))
    #     assert(y_true.shape == y_pred.shape)
    #     assert(len(y_true.shape) == 1)

    #     if isinstance(y_true, torch.Tensor):
    #         return {'mae': torch.mean(torch.abs(y_pred - y_true)).cpu().item()}
    #     else:
    #         return {'mae': float(np.mean(np.absolute(y_pred - y_true)))}
        
    # 基于二分类进行评估
    def eval(self, input_dict):
        '''
            y_true: numpy.ndarray or torch.Tensor of shape (num_graphs,)
            y_pred: numpy.ndarray or torch.Tensor of shape (num_graphs,)
            y_true and y_pred need to be of the same type (either numpy.ndarray or torch.Tensor)
        '''
        assert('y_pred' in input_dict)
        assert('y_true' in input_dict)

        y_pred, y_true = input_dict['y_pred'], input_dict['y_true']

        assert((isinstance(y_true, np.ndarray) and isinstance(y_pred, np.ndarray))
                or
                (isinstance(y_true, torch.Tensor) and isinstance(y_pred, torch.Tensor)))
        assert(y_true.shape == y_pred.shape)
        assert(len(y_true.shape) == 1)

        if isinstance(y_true, torch.Tensor):
            y_pred = torch.where(y_pred>0.5, torch.ones_like(y_pred), torch.zeros_like(y_pred))
            return {'mae': torch.mean(torch.abs(y_pred - y_true)).cpu().item()}
        else:
            return {'mae': float(np.mean(np.absolute(y_pred - y_true)))}


    def save_test_submission(self, input_dict, dir_path: str):
        '''
            save test submission file at dir_path
        '''
        assert('y_pred' in input_dict)

        y_pred = input_dict['y_pred']

        filename = osp.join(dir_path, 'y_pred_pcqm4m')

        assert(isinstance(filename, str))
        assert(isinstance(y_pred, np.ndarray) or isinstance(y_pred, torch.Tensor))

        if not osp.exists(dir_path):
            os.makedirs(dir_path)

        if isinstance(y_pred, torch.Tensor):
            y_pred = y_pred.numpy()
        y_pred = y_pred.astype(np.float32)
        np.savez_compressed(filename, y_pred = y_pred)


if __name__ == "__main__":
    dataset = MyDataset('dataset')

    from torch_geometric.data import DataLoader
    from tqdm import tqdm
    dataset_size = len(dataset)
    indices = list(range(dataset_size))
    train_scale = int(np.floor(0.7*dataset_size))
    test_scale = int(np.floor(0.1*dataset_size))
    valid_scale = int(np.floor(0.2*dataset_size))
    np.random.shuffle(indices)
    train_indices = indices[:train_scale]
    test_indices = indices[train_scale:train_scale+test_scale]
    valid_indices = indices[train_scale+test_scale:]
    train_data = dataset[train_indices]
    valid_data = dataset[valid_indices]
    test_data = dataset[test_indices]
    train_loader = DataLoader(train_data, batch_size=256, shuffle=True, num_workers=4)
    valid_loader = DataLoader(valid_data, batch_size=256, shuffle=False, num_workers=4)
    test_loader = DataLoader(test_data, batch_size=256, shuffle=False, num_workers=4)

    # dataloader = DataLoader(dataset, batch_size=256, shuffle=True, num_workers=4)
    for batch in tqdm(train_loader):
        print(batch)
        x, edge_index, edge_attr = batch.x, batch.edge_index, batch.edge_attr
        print(edge_index.type())
        
        pass
