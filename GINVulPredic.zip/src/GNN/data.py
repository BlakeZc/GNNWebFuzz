import os.path as osp
from typing import Callable, Optional

import torch
from torch_geometric.data import InMemoryDataset

class Dataset(InMemoryDataset):
    def __init__(self, root: Optional[str] = None, transform: Optional[Callable] = None, pre_transform: Optional[Callable] = None, pre_filter: Optional[Callable] = None):
        super().__init__(root, transform, pre_transform, pre_filter)

    @property
    def raw_file_names(self):
        return super().raw_file_names

    @property
    def processed_file_names(self):
        return super().processed_file_names

    def process(self):
        pass