from typing import Dict
from xml.etree import ElementTree
import json
# from src.dicts import CWE_NUM

class parserXML:
    def __init__(self) -> None:
        # 全局变量
        self.datas = {}
        pass

    def parserXML(self, filePath: str) -> Dict:
        # 加载xml文件
        tree = ElementTree.parse(filePath)
        # 获取根节点
        root = tree.getroot()

        # 遍历根节点的子节点
        for child in root:
            data = {}
            # 解析xml
            attrib = child.attrib

            # description = child.find('description')
            # descriptionText = description.text
            # descriptionList = descriptionText.split("<br />")
            # securitySigns = descriptionList[0]

            file = child.find('file')
            path = file.attrib['path']
            # checksum = file.attrib['checksum']

            flaw = file.find('flaw')
            if(flaw != None):
                # line = flaw.attrib['line']
                name = flaw.attrib['name']
                securitySigns = 'vulnerable'
            else:
                # line = None
                name = None
                securitySigns = 'security'

            # 将 path\name\security 等信息写入字典
            # data['id'] = attrib['id']
            data['security'] = securitySigns
            # data['path'] = path
            # data['checksum'] = checksum
            # data['line'] = line
            data['name'] = name

            self.datas[path] = data
        # print(self.datas)
        return self.datas
    
    def writeFile(self, filePath: str) -> None:
        with open(filePath, 'w') as fileObj:
            jsonDatas = json.dumps(self.datas)
            fileObj.write(jsonDatas)
            fileObj.close()
        
# if __name__ == "__main__":
#     parserXML = parserXML()
#     parserXML.parserXML("D:\\manifest-103-RAjiQO.xml")
#     parserXML.writeFile("D:\\manifest-103-RAjiQO.txt")
