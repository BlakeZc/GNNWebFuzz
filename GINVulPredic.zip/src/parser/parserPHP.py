import subprocess
import os 
import re
from src.parser.XML.parserXML import parserXML
import pydot
import torch
import pickle
import numpy as np
from src.word2vec.word2vec import EmbeddingModel, vocab_size, EMBEDDING_SIZE

class parserPHP2CfgForTrain:
    def __init__(self) -> None:
        self.PROJECT_ROOT = os.getcwd()
        self.datasetDict = None

    # 解析XML文件数据
    def parserXMLJSON(self, jsonfile: str) -> None:
        parserXMLfile = parserXML()
        self.datasetDict = parserXMLfile.parserXML(jsonfile)

    # 解析一个PHP文件，并生成对应的CFG，保存至文件中
    def parserPHP(self, phpFileName: str) -> None:
        phpFilePath = self.PROJECT_ROOT + '\\dataset\\raw_php_dir\\' + phpFileName
        dotFilePath = self.PROJECT_ROOT + '\\dataset\\php_cfg_dir\\' + phpFileName.split('.')[0]
        commandLine = 'php ' + self.PROJECT_ROOT + '\\src\\parser\\PHP\\demo.php ' + phpFilePath + ' > ' + dotFilePath + '.dot'
        print(commandLine)
        try:
            logFilePath = self.PROJECT_ROOT + '\\logs\\log.txt'
            with open(logFilePath, 'w') as logfile:
                proc = subprocess.Popen(commandLine, shell=True, stdout=logfile)
        except Exception as e:
            print(e)
            raise e
        
    # 批量生成CFG
    def generateCFG(self) -> None:
        if self.datasetDict is None:
            return 
        for key in self.datasetDict:
            self.parserPHP(key)

    # 提取源码文件中的PHP代码
    def filterPHP(self) -> None:
        if self.datasetDict is None:
            return 
        for key in self.datasetDict:
            phpFilePath = self.PROJECT_ROOT + '\\dataset\\raw_dir\\' + key
            with open(phpFilePath, 'r') as f:
                content = f.read()
                reStr = r'<\?php.+\?>'
                resp = re.findall(reStr, content, re.S)
                f.close()
            newPhpFilePath = self.PROJECT_ROOT + '\\dataset\\raw_php_dir\\' + key
            with open(newPhpFilePath, 'w') as f:
                f.write(resp[0])
                f.close()

    # 解析CFG dot文件，利用word2vec模型编码
    def parserCFGDotFile(self) -> None:
        if self.datasetDict is None:
            return 
        GraphList = []
        edgeAttrTypeList = {'"if"':0, '"else"':1, '"target"':2, '"stmts"':3, 'None':4}
        for key, value in self.datasetDict.items():
            dotFilePath = self.PROJECT_ROOT + '\\dataset\\php_cfg_dir\\' + key.split('.')[0] + '.dot'
            graphs = pydot.graph_from_dot_file(dotFilePath)
            # print(graphs)
            if graphs is None:
                continue
            for graph in graphs:
                Graph = {}
                nodes = graph.get_nodes()
                
                nodeDict = {}
                nodeAttrList = []
                i = 0
                for node in nodes:
                    nodeName = node.get_name()
                    nodeAttr = node.obj_dict['attributes']
                    nodeDict[nodeName] = i
                    i += 1
                    nodeAttrList.append(nodeAttr['label'])
                    # print(nodeAttr['label'])
                    self.saveText2File('logs\\text.txt', nodeAttr['label'])
                edges = graph.get_edges()
                edgeList = []
                edgeAttrList = []
                for edge in edges:
                    edgeSource = edge.get_source()
                    edgeDestination = edge.get_destination()
                    edgeAttr = edge.obj_dict['attributes']
                    edgeList.append([nodeDict[edgeSource], nodeDict[edgeDestination]])
                    
                    # print(edgeAttr)
                    if 'label' in edgeAttr.keys() and edgeAttr['label'] in edgeAttrTypeList.keys():
                        edgeAttrList.append(edgeAttrTypeList[edgeAttr['label']])
                    else:
                        edgeAttrList.append(edgeAttrTypeList['None'])
                        
                # 处理字符串列表类型节点属性列表 为tensor
                nodeVecList = []
                for nodeCode in nodeAttrList:
                    nodeCode = nodeCode.strip('"')
                    nodeCode = re.split(r"\\l|[\s]+", nodeCode)
                    nodeCode = list(filter(None, nodeCode))
                    wordList = []
                    for sentence in nodeCode:
                        sentenceWordList = re.split(r"(['{}():[\]<>])", sentence)
                        wordList += sentenceWordList
                    wordList = list(filter(None, wordList))
                    VecList = []
                    for word in wordList:
                        wordVec = word2vec(word)
                        VecList.append(wordVec)
                    # 对VecList进行处理（先转成一维，再进行补充和截取）
                    lenVecList = len(VecList)
                    zeroList = [0] * 30
                    if lenVecList < 300:
                        VecList += (300 - lenVecList) * [zeroList]
                    else:
                        VecList = VecList[0:300]
                    nodeVecList += VecList
                x = torch.tensor(np.array(nodeVecList))
                x = x.reshape(len(nodeAttrList), 9000)
                print(x.shape)
                Graph['x'] = x

                # 处理edge_index\edge_attr\y\num_nodes为tensor
                edge_index = torch.LongTensor(edgeList).T
                print(edge_index.shape)
                Graph['edge_index'] = edge_index
                edge_attr = torch.tensor(edgeAttrList).reshape(len(edgeList), 1)
                print(edge_attr.shape)
                Graph['edge_attr'] = edge_attr
                if value['security'] == 'vulnerable':
                    y = 1
                else:
                    y = 0
                Graph['y'] = torch.Tensor([y])
                print(Graph['y'].shape)
                Graph['num_nodes'] = len(nodes)
                # Graph['node_dict'] = nodeDict
                GraphList.append(Graph)
                # print(Graph)
                print('')
        
        torch.save(GraphList, 'dataset/raw_dir/cwe_79.th')
        print(GraphList)
        
        
    # 解析CFG dot文件，利用word2idx对单词编码
    def parserCFGDotFileWithWord2idx(self) -> None:
        if self.datasetDict is None:
            return 
        GraphList = []
        edgeAttrTypeList = {'"if"':0, '"else"':1, '"target"':2, '"stmts"':3, 'None':4}
        for key, value in self.datasetDict.items():
            dotFilePath = self.PROJECT_ROOT + '\\dataset\\php_cfg_dir\\' + key.split('.')[0] + '.dot'
            graphs = pydot.graph_from_dot_file(dotFilePath)
            # print(graphs)
            if graphs is None:
                continue
            for graph in graphs:
                Graph = {}
                nodes = graph.get_nodes()
                
                nodeDict = {}
                nodeAttrList = []
                i = 0
                for node in nodes:
                    nodeName = node.get_name()
                    nodeAttr = node.obj_dict['attributes']
                    nodeDict[nodeName] = i
                    i += 1
                    nodeAttrList.append(nodeAttr['label'])
                    # print(nodeAttr['label'])
                    self.saveText2File('logs\\text.txt', nodeAttr['label'])
                edges = graph.get_edges()
                edgeList = []
                edgeAttrList = []
                for edge in edges:
                    edgeSource = edge.get_source()
                    edgeDestination = edge.get_destination()
                    edgeAttr = edge.obj_dict['attributes']
                    edgeList.append([nodeDict[edgeSource], nodeDict[edgeDestination]])
                    
                    # print(edgeAttr)
                    if 'label' in edgeAttr.keys() and edgeAttr['label'] in edgeAttrTypeList.keys():
                        edgeAttrList.append(edgeAttrTypeList[edgeAttr['label']])
                    else:
                        edgeAttrList.append(edgeAttrTypeList['None'])
                        
                # 处理字符串列表类型节点属性列表 为tensor
                nodeVecList = []
                for nodeCode in nodeAttrList:
                    nodeCode = nodeCode.strip('"')
                    nodeCode = re.split(r"\\l|[\s]+", nodeCode)
                    nodeCode = list(filter(None, nodeCode))
                    wordList = []
                    for sentence in nodeCode:
                        sentenceWordList = re.split(r"(['{}():[\]<>])", sentence)
                        wordList += sentenceWordList
                    wordList = list(filter(None, wordList))
                    VecList = []
                    for word in wordList:
                        wordIdx = word2idx(word)
                        VecList.append(wordIdx)
                    # 对VecList进行处理（先转成一维，再进行补充和截取）
                    lenVecList = len(VecList)
                    zeroList = 0
                    if lenVecList < 1000:
                        VecList += (1000 - lenVecList) * [zeroList]
                    else:
                        VecList = VecList[0:1000]
                    nodeVecList += VecList
                x = torch.tensor(np.array(nodeVecList))
                x = x.reshape(len(nodeAttrList), 1000)
                print(x.shape)
                Graph['x'] = x

                # 处理edge_index\edge_attr\y\num_nodes为tensor
                edge_index = torch.LongTensor(edgeList).T
                print(edge_index.shape)
                Graph['edge_index'] = edge_index
                edge_attr = torch.tensor(edgeAttrList).reshape(len(edgeList), 1)
                print(edge_attr.shape)
                Graph['edge_attr'] = edge_attr
                if value['security'] == 'vulnerable':
                    y = 1
                else:
                    y = 0
                Graph['y'] = torch.Tensor([y])
                print(Graph['y'].shape)
                Graph['num_nodes'] = len(nodes)
                # Graph['node_dict'] = nodeDict
                GraphList.append(Graph)
                # print(Graph)
                print('')
        
        torch.save(GraphList, 'dataset/raw_dir/cwe_79_idx.th')
        print(GraphList)

        # # 将GraphList写入csv文件
        # fileds_names = ('x', 'edge_index', 'edge_attr', 'y', 'num_nodes', 'node_dict')
        # with open('dataset/raw_dir/cwe_79.csv', 'w', encoding='utf-8' ,newline="") as outfile:
        #     writer = DictWriter(outfile, fileds_names)
        #     writer.writeheader()
        #     writer.writerows(GraphList)
    
    def saveText2File(self, path: str, textStr: str) -> None:
        textStr = textStr.strip('"')
        # print(textStr)
        filePath = self.PROJECT_ROOT + '\\' + path
        with open(filePath, 'a') as f:
            f.write(textStr + "\r\n")
            f.close
            
class parserPHP2Cfg:
    def __init__(self, path: str, taskName: str) -> None:
        self.PROJECT_ROOT = path
        self.phpFilePaths = []
        self.taskName = taskName

    # # 解析XML文件数据
    # def parserXMLJSON(self, jsonfile: str) -> None:
    #     parserXMLfile = parserXML()
    #     self.datasetDict = parserXMLfile.parserXML(jsonfile)
    
    # 解析待测项目目录中的PHP文件，生成php文件列表datasetDict
    def parserFileSys(self, excludedFiles: list) -> None:
        for root, dirs, files in os.walk(self.PROJECT_ROOT):
            if os.path.relpath(root, self.PROJECT_ROOT) in excludedFiles:
                dirs[:] = []
                continue
            for file in files:
                if os.path.splitext(file)[1] == ".php":
                    filePath = os.path.join(root, file)
                    if os.path.relpath(filePath, self.PROJECT_ROOT) in excludedFiles:
                        continue
                    fileRelPath = os.path.relpath(filePath, self.PROJECT_ROOT)
                    self.phpFilePaths.append(fileRelPath)
        print(self.phpFilePaths)

    # 提取源码文件中的PHP代码
    def filterPHP(self) -> None:
        if self.phpFilePaths is None:
            return 
        for file in self.phpFilePaths:
            phpFilePath = os.path.join(self.PROJECT_ROOT, file)
            with open(phpFilePath, 'r', encoding='UTF-8') as f:
                content = f.read()
                reStr = r'<\?php.+\?>'
                resp = re.findall(reStr, content, re.S)
                if not resp:
                    reStr = r'<\?php.+'
                    resp = re.findall(reStr, content, re.S)
                f.close()
            newPhpFilePath = os.path.join(self.PROJECT_ROOT + '_php', file)
            newPhpFileDir = os.path.dirname(newPhpFilePath)
            if not os.path.isdir(newPhpFileDir):
                os.makedirs(newPhpFileDir)
            with open(newPhpFilePath, 'w', encoding='UTF-8') as f:
                f.write(resp[0])
                f.close()

    # 解析一个PHP文件，并生成对应的CFG，保存至文件中
    def parserPHP(self, phpFileName: str) -> None:
        phpFilePath = os.path.join(self.PROJECT_ROOT + "_php", phpFileName)
        dotFilePath = os.path.splitext(phpFilePath)[0] + '.dot'
        projectDir = os.getcwd()
        commandLine = 'php ' + os.path.join(projectDir, 'src\\parser\\PHP\\demo.php') + ' ' + phpFilePath + ' > ' + dotFilePath
        print(commandLine)
        try:
            logFilePath = os.path.join(projectDir, 'logs\\log.txt') 
            with open(logFilePath, 'w') as logfile:
                proc = subprocess.Popen(commandLine, shell=True, stdout=logfile)
        except Exception as e:
            print(e)
            raise e
        
    # 批量生成CFG
    def generateCFG(self) -> None:
        if self.phpFilePaths is None:
            return 
        for key in self.phpFilePaths:
            self.parserPHP(key)

    

    # 解析CFG dot文件，利用word2vec模型编码
    def parserCFGDotFile(self) -> None:
        if self.phpFilePaths is None:
            return 
        GraphList = []
        edgeAttrTypeList = {'"if"':0, '"else"':1, '"target"':2, '"stmts"':3, 'None':4}
        for file in self.phpFilePaths:
            dotFilePath = os.path.splitext(os.path.join(self.PROJECT_ROOT + '_php', file))[0] + '.dot'
            try:
                graphs = pydot.graph_from_dot_file(dotFilePath, encoding='UTF-8')
            except Exception as e:
                print(e)
                continue
            # print(graphs)
            if graphs is None:
                continue
            for graph in graphs:
                Graph = {}
                nodes = graph.get_nodes()
                
                nodeDict = {}
                nodeAttrList = []
                i = 0
                for node in nodes:
                    nodeName = node.get_name()
                    nodeAttr = node.obj_dict['attributes']
                    nodeDict[nodeName] = i
                    i += 1
                    nodeAttrList.append(nodeAttr['label'])
                    # print(nodeAttr['label'])
                    # self.saveText2File('logs\\text.txt', nodeAttr['label'])
                edges = graph.get_edges()
                edgeList = []
                edgeAttrList = []
                for edge in edges:
                    edgeSource = edge.get_source()
                    edgeDestination = edge.get_destination()
                    edgeAttr = edge.obj_dict['attributes']
                    edgeList.append([nodeDict[edgeSource], nodeDict[edgeDestination]])
                    
                    # print(edgeAttr)
                    if 'label' in edgeAttr.keys() and edgeAttr['label'] in edgeAttrTypeList.keys():
                        edgeAttrList.append(edgeAttrTypeList[edgeAttr['label']])
                    else:
                        edgeAttrList.append(edgeAttrTypeList['None'])
                        
                # 处理字符串列表类型节点属性列表 为tensor
                nodeVecList = []
                for nodeCode in nodeAttrList:
                    nodeCode = nodeCode.strip('"')
                    nodeCode = re.split(r"\\l|[\s]+", nodeCode)
                    nodeCode = list(filter(None, nodeCode))
                    wordList = []
                    for sentence in nodeCode:
                        sentenceWordList = re.split(r"(['{}():[\]<>])", sentence)
                        wordList += sentenceWordList
                    wordList = list(filter(None, wordList))
                    VecList = []
                    for word in wordList:
                        wordVec = word2vec(word)
                        VecList.append(wordVec)
                    # 对VecList进行处理（先转成一维，再进行补充和截取）
                    lenVecList = len(VecList)
                    zeroList = [0] * 30
                    if lenVecList < 300:
                        VecList += (300 - lenVecList) * [zeroList]
                    else:
                        VecList = VecList[0:300]
                    nodeVecList += VecList
                x = torch.tensor(np.array(nodeVecList))
                x = x.reshape(len(nodeAttrList), 9000)
                print(x.shape)
                Graph['x'] = x

                # 处理edge_index\edge_attr\y\num_nodes为tensor
                edge_index = torch.LongTensor(edgeList).T
                print(edge_index.shape)
                Graph['edge_index'] = edge_index
                edge_attr = torch.tensor(edgeAttrList).reshape(len(edgeList), 1)
                print(edge_attr.shape)
                Graph['edge_attr'] = edge_attr
                Graph['y'] = file
                # if value['security'] == 'vulnerable':
                #     y = 1
                # else:
                #     y = 0
                # Graph['y'] = torch.Tensor([y])
                # print(Graph['y'].shape)
                Graph['filename'] = file
                Graph['num_nodes'] = len(nodes)
                # Graph['node_dict'] = nodeDict
                GraphList.append(Graph)
                # print(Graph)
                # print('')
        
        saveFileName = os.path.join('dataset', self.taskName + '.th')
        torch.save(GraphList, saveFileName)
        # print(GraphList)
        
        
    # 解析CFG dot文件，利用word2idx对单词编码
    def parserCFGDotFileWithWord2idx(self) -> None:
        if self.phpFilePaths is None:
            return 
        GraphList = []
        edgeAttrTypeList = {'"if"':0, '"else"':1, '"target"':2, '"stmts"':3, 'None':4}
        for file in self.phpFilePaths:
            dotFilePath = os.path.splitext(os.path.join(self.PROJECT_ROOT + '_php', file))[0] + '.dot'
            try:
                graphs = pydot.graph_from_dot_file(dotFilePath, encoding='UTF-8')
            except Exception as e:
                print(e)
                continue
            # print(graphs)
            if graphs is None:
                continue
            for graph in graphs:
                Graph = {}
                nodes = graph.get_nodes()
                
                nodeDict = {}
                nodeAttrList = []
                i = 0
                for node in nodes:
                    nodeName = node.get_name()
                    nodeAttr = node.obj_dict['attributes']
                    nodeDict[nodeName] = i
                    i += 1
                    nodeAttrList.append(nodeAttr['label'])
                    # print(nodeAttr['label'])
                    # self.saveText2File('logs\\text.txt', nodeAttr['label'])
                edges = graph.get_edges()
                edgeList = []
                edgeAttrList = []
                for edge in edges:
                    edgeSource = edge.get_source()
                    edgeDestination = edge.get_destination()
                    edgeAttr = edge.obj_dict['attributes']
                    edgeList.append([nodeDict[edgeSource], nodeDict[edgeDestination]])
                    
                    # print(edgeAttr)
                    if 'label' in edgeAttr.keys() and edgeAttr['label'] in edgeAttrTypeList.keys():
                        edgeAttrList.append(edgeAttrTypeList[edgeAttr['label']])
                    else:
                        edgeAttrList.append(edgeAttrTypeList['None'])
                        
                # 处理字符串列表类型节点属性列表 为tensor
                nodeVecList = []
                for nodeCode in nodeAttrList:
                    nodeCode = nodeCode.strip('"')
                    nodeCode = re.split(r"\\l|[\s]+", nodeCode)
                    nodeCode = list(filter(None, nodeCode))
                    wordList = []
                    for sentence in nodeCode:
                        sentenceWordList = re.split(r"(['{}():[\]<>])", sentence)
                        wordList += sentenceWordList
                    wordList = list(filter(None, wordList))
                    VecList = []
                    for word in wordList:
                        wordIdx = word2idx(word)
                        VecList.append(wordIdx)
                    # 对VecList进行处理（先转成一维，再进行补充和截取）
                    lenVecList = len(VecList)
                    zeroList = 0
                    if lenVecList < 1000:
                        VecList += (1000 - lenVecList) * [zeroList]
                    else:
                        VecList = VecList[0:1000]
                    nodeVecList += VecList
                x = torch.tensor(np.array(nodeVecList))
                x = x.reshape(len(nodeAttrList), 1000)
                print(x.shape)
                Graph['x'] = x

                # 处理edge_index\edge_attr\y\num_nodes为tensor
                edge_index = torch.LongTensor(edgeList).T
                print(edge_index.shape)
                Graph['edge_index'] = edge_index
                edge_attr = torch.tensor(edgeAttrList).reshape(len(edgeList), 1)
                print(edge_attr.shape)
                Graph['edge_attr'] = edge_attr
                Graph['y'] = file
                # if value['security'] == 'vulnerable':
                #     y = 1
                # else:
                #     y = 0
                # Graph['y'] = torch.Tensor([y])
                # print(Graph['y'].shape)
                Graph['filename'] = file
                Graph['num_nodes'] = len(nodes)
                # Graph['node_dict'] = nodeDict
                GraphList.append(Graph)
                # print(Graph)
                # print('')
        
        saveFileName = os.path.join('dataset', self.taskName + '_idx.th')
        torch.save(GraphList, saveFileName)
        # print(GraphList)

        # # 将GraphList写入csv文件
        # fileds_names = ('x', 'edge_index', 'edge_attr', 'y', 'num_nodes', 'node_dict')
        # with open('dataset/raw_dir/cwe_79.csv', 'w', encoding='utf-8' ,newline="") as outfile:
        #     writer = DictWriter(outfile, fileds_names)
        #     writer.writeheader()
        #     writer.writerows(GraphList)
    
    def saveText2File(self, path: str, textStr: str) -> None:
        textStr = textStr.strip('"')
        # print(textStr)
        filePath = self.PROJECT_ROOT + '\\' + path
        with open(filePath, 'a') as f:
            f.write(textStr + "\r\n")
            f.close

def loadWord2vecModel():
    model = EmbeddingModel(vocab_size, EMBEDDING_SIZE)
    model.load_state_dict(torch.load("model/embedding-{}.th".format(EMBEDDING_SIZE)))
    embedding_weights = model.input_embedding()
    return embedding_weights

def word2vec(word):
    with open('model/word2idx.pkl', 'rb') as f:
        word2idx = pickle.load(f)
        f.close()
    
    embedding_weights = loadWord2vecModel()
    wordVec = embedding_weights[word2idx[word]]
    return wordVec

def word2idx(word):
    with open('model/word2idx.pkl', 'rb') as f:
        word2idx = pickle.load(f)
        f.close()
    if word in word2idx:
        return word2idx[word]
    else:
        return 242





