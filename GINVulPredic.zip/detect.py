import os, argparse, torch
import numpy as np
from torch_geometric.loader import DataLoader
from src.parser.parserPHP import parserPHP2Cfg
from src.GNN.code_data import MyDataset, Evaluator
from src.GNN.gin_graph import GINGraphPooling

def parse_args():
    parser = argparse.ArgumentParser(description='PHP code preprocessing and vulnerability prediction')
    parser.add_argument("--path", type=str, help="Project Directory")
    parser.add_argument('--task_name', type=str, default='GINGraphPooling',
                        help='task name')
    parser.add_argument('--device', type=int, default=0,
                        help='which gpu to use if any (default: 0)')
    parser.add_argument('--num_layers', type=int, default=5,
                        help='number of GNN message passing layers (default: 5)')
    parser.add_argument('--graph_pooling', type=str, default='sum',
                        help='graph pooling strategy mean or sum (default: sum)')
    parser.add_argument('--emb_dim', type=int, default=256,
                        help='dimensionality of hidden units in GNNs (default: 256)')
    parser.add_argument('--drop_ratio', type=float, default=0.,
                        help='dropout ratio (default: 0.)')
    parser.add_argument('--save_test', action='store_true')
    parser.add_argument('--batch_size', type=int, default=128,
                        help='input batch size for training (default: 512)')
    parser.add_argument('--epochs', type=int, default=100,
                        help='number of epochs to train (default: 100)')
    parser.add_argument('--num_workers', type=int, default=4,
                        help='number of workers (default: 4)')
    parser.add_argument('--dataset_root', type=str, default="dataset",
                        help='dataset root')
    parser.add_argument('--exclude_file', type=str, default="exclude.txt",
                        help="file containing the list of excluded files")
    args = parser.parse_args()
    return args
    
def prepartion(args):
    save_dir = os.path.join('saves', args.task_name)
    if not os.path.exists(save_dir):
        print("File does not exist. ")
        raise Exception

    args.save_dir = save_dir
    os.makedirs(args.save_dir, exist_ok=True)
    args.device = torch.device("cuda:" + str(args.device)) if torch.cuda.is_available() else torch.device("cpu")
    args.output_file = open(os.path.join(args.save_dir, 'FileScore.py'), 'w')
    
    exclude_files = []
    with open(args.exclude_file, 'r', encoding="utf-8") as f:
        lines = f.readlines()
        for line in lines:
            exclude_files.append(line.replace('\n', ''))
        f.close()
    args.exclude_files = exclude_files
        
def saveResultToPy(result: dict, args):
    PyCodeHead = '''SCORE = {\n'''
    PyCodeEnd = '''}'''
    args.output_file.write(PyCodeHead)
    for k,v in result.items():
        k = k.replace('\\', '\\\\')
        args.output_file.write(f'    "{k}": {v:.2f},\n')
    args.output_file.write(PyCodeEnd)

if __name__ == '__main__':
    # # 以下是PHP源码处理代码
    args = parse_args()
    prepartion(args)
    parser = parserPHP2Cfg(args.path, args.task_name)
    parser.parserFileSys(args.exclude_files)

    parser.filterPHP()

    parser.generateCFG()

    # parser.parserCFGDotFile()
    parser.parserCFGDotFileWithWord2idx()
    
    
    nn_params = {
        'num_layers': args.num_layers,
        'emb_dim': args.emb_dim,
        'drop_ratio': args.drop_ratio,
        'graph_pooling': args.graph_pooling
    }
    dataset = MyDataset(root=args.dataset_root, taskName=args.task_name)
    dataset_size = len(dataset)
    indices = list(range(dataset_size))
    data_loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers)
    device = args.device
    model = GINGraphPooling(**nn_params).to(device)
    checkpoint = torch.load(os.path.join(args.save_dir, 'checkpoint.pt'))
    model.load_state_dict(checkpoint['model_state_dict'])
    label = []
    y = []
    with torch.no_grad():
        for predata in data_loader:
            predata = predata.to(device)
            y += predata['y']
            pred = model(predata).view(-1)
            label.append(pred.detach().cpu())
    label = torch.cat(label, dim=0)
    dic = dict(zip(y, label))
    print(dic)
    # 将预测结果保存至self.save_dir/presult.php文件中，并保存为php代码
    saveResultToPy(dic, args)
