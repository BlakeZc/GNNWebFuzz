<?php
$id = $_GET['id'];
if ($id == 0){
	echo 'True';
} 
