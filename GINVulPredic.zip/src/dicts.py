
CWE_NUM = {
    "862": "Missing Authorization",
    "078": "OS Command Injection",
    "089": "SQL Injection",
    "090": "LDAP Injection",
    "091": "XML Injection",
    "095": "File Injection",
    "098": "PHP Remote File Inclusion",
    "311": "Missing Encryption of Sensitive Data",
    "327": "Use of a Broken or Risky Cryptographic Algorithm",
    "209": "Information Exposure Through an Error Message",
    "601": "URL Redirection to Untrusted Site",
    "079": "Cross-site Scripting"
}