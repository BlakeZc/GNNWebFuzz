from src.parser.parserPHP import parserPHP2CfgForTrain

# # 以下是PHP源码处理代码
parser = parserPHP2CfgForTrain()
parser.parserXMLJSON('./dataset/raw_dir/manifest.xml')

parser.filterPHP()

parser.generateCFG()

# parser.parserCFGDotFile()
parser.parserCFGDotFileWithWord2idx()

