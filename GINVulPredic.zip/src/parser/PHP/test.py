import pydot
import os

cur = os.getcwd()
graph1 = pydot.graph_from_dot_file(os.path.join(cur, "Assertion.dot"))
for graph in graph1:
    nodes = graph.get_nodes()
                
    nodeDict = {}
    nodeAttrList = []
    i = 0
    for node in nodes:
        nodeName = node.get_name()
        nodeAttr = node.obj_dict['attributes']
        nodeDict[nodeName] = i
        i += 1
        nodeAttrList.append(nodeAttr['label'])
        # print(nodeAttr['label'])
    edges = graph.get_edges()
    edgeList = []
    edgeAttrList = []
    for edge in edges:
        edgeSource = edge.get_source()
        edgeDestination = edge.get_destination()
        edgeAttr = edge.obj_dict['attributes']
        edgeList.append([nodeDict[edgeSource], nodeDict[edgeDestination]])
