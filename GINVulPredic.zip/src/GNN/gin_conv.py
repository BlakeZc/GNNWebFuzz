import torch
from torch import nn
from torch_geometric.nn import MessagePassing
import torch.nn.functional as F
# from ogb.graphproppred.mol_encoder import BondEncoder
from src.GNN.mol_encoder import EdgeEncoder
# from ogb.graphproppred.mol_encoder import BondEncoder

### GIN convolution along the graph structure
class GINConv(MessagePassing):
    def __init__(self, emb_dim):
        '''
            emb_dim (int): node embedding dimensionality
        '''

        super(GINConv, self).__init__(aggr = "add")

        self.mlp = nn.Sequential(nn.Linear(emb_dim, emb_dim), nn.BatchNorm1d(emb_dim), nn.ReLU(), nn.Linear(emb_dim, emb_dim))
        self.eps = nn.Parameter(torch.Tensor([0]))
        self.edge_encoder = EdgeEncoder(emb_dim = emb_dim)

    def forward(self, x, edge_index, edge_attr):
        edge_embedding = self.edge_encoder(edge_attr) # 先将类别型边属性转换为边嵌入
        eps1 = 1 + self.eps
        eps1x = eps1*x
        pro = self.propagate(edge_index, x=x, edge_attr=edge_embedding)
        out = self.mlp(eps1x + pro)
        return out

    def message(self, x_j, edge_attr):
        return F.relu(x_j + edge_attr)  # 将节点信息和边信息融合
        
    def update(self, aggr_out):
        return aggr_out
