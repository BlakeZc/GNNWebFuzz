import test
print(test.SCORE)