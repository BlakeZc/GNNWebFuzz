import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.utils.data as tud
from torch.optim import SGD

from collections import Counter
import numpy as np
import random
import math

import pandas as pd
import scipy
import sklearn
from sklearn.metrics.pairwise import cosine_similarity
import re
import pickle

random.seed(1)
np.random.seed(1)
torch.manual_seed(1)

C = 3 # context window
K = 15 # number of negative samples
epochs = 2 # 迭代次数
MAX_VOCAB_SIZE = 10000
EMBEDDING_SIZE = 30
batch_size = 256
lr = 0.05 # 学习率

use_cuda = torch.cuda.is_available()
if use_cuda:
    device = torch.device('cuda:0')
    torch.cuda.set_device('cuda:0')
    # cudnn.benchmark = True
else:
    device = torch.device('cpu')
# print(device)

# 读语料库
with open('src/word2vec/text.txt') as f:
    text = f.read() # 得到文本内容

text = re.split(r"\\l|[\s]+", text)
text = list(filter(None, text))
textlist = []
for sentence in text:
    sentenceWordList = re.split(r"(['{}():[\]<>])", sentence)
    textlist += sentenceWordList
text = list(filter(None, textlist))
with open("textlist.txt", 'w') as f:
    f.write(str(text))
    f.close()
vocab_dict = dict(Counter(text))    # .most_common(MAX_VOCAB_SIZE - 1)) # 得到单词字典表，key是单词，value是次数
vocab_dict['<UNK>'] = len(text) - np.sum(list(vocab_dict.values())) # 把不常用的单词都编码为"<UNK>"
vocab_size = len(vocab_dict)
# print(len(vocab_dict))
idx2word = [word for word in vocab_dict.keys()]
word2idx = {word:i for i, word in enumerate(idx2word)}
word_counts = np.array([count for count in vocab_dict.values()], dtype=np.float32)
word_freqs = word_counts / np.sum(word_counts)
word_freqs = word_freqs ** (3./4.)
# print("vocab_size: ", vocab_size)
# 保存word2idx变量值
with open('model/word2idx.pkl', 'wb') as f:
    pickle.dump(word2idx, f)
    f.close()

# 首先，DataLoader得继承torch.utils.data.Dataset
class WordEmbeddingDataset(tud.Dataset):
    def __init__(self, text, word2idx, idx2word, word_freqs, word_counts):
        ''' text: a list of words, all text from the training dataset
            word2idx: the dictionary from word to index
            idx2word: index to word mapping
            word_freqs: the frequency of each word
            word_counts: the word counts
        '''
        super(WordEmbeddingDataset, self).__init__() # #通过父类初始化模型，然后重写两个方法
        self.text_encoded = [word2idx.get(word, word2idx['<UNK>']) for word in text] # 把单词数字化表示。如果不在词典中，也表示为unk
        self.text_encoded = torch.LongTensor(self.text_encoded) # nn.Embedding需要传入LongTensor类型
        self.word2idx = word2idx
        self.idx2word = idx2word
        self.word_freqs = torch.Tensor(word_freqs)
        self.word_counts = torch.Tensor(word_counts)
        
        
    def __len__(self):
        return len(self.text_encoded) # 返回所有单词的总数，即item的总数
    
    def __getitem__(self, idx):
        ''' 这个function返回以下数据用于训练
            - 中心词
            - 这个单词附近的positive word
            - 随机采样的K个单词作为negative word
        '''
        center_words = self.text_encoded[idx] # 取得中心词
        pos_indices = list(range(idx - C, idx)) + list(range(idx + 1, idx + C + 1)) # 先取得中心左右各C个词的索引
        pos_indices = [i % len(self.text_encoded) for i in pos_indices] # 为了避免索引越界，所以进行取余处理
        pos_words = self.text_encoded[pos_indices] # tensor(list)
        neg_words = torch.multinomial(self.word_freqs, K * pos_words.shape[0], True)
        # torch.multinomial作用是对self.word_freqs做K * pos_words.shape[0]次取值，输出的是self.word_freqs对应的下标
        # 取样方式采用有放回的采样，并且self.word_freqs数值越大，取样概率越大
        # 每采样一个正确的单词(positive word)，就采样K个错误的单词(negative word)，pos_words.shape[0]是正确单词数量
        return center_words, pos_words, neg_words

class EmbeddingModel(nn.Module):
    def __init__(self, vocab_size, embed_size):
        super(EmbeddingModel, self).__init__()
        
        self.vocab_size = vocab_size
        self.embed_size = embed_size
        
        # 初始化
        initrange = 0.5/self.embed_size
        self.in_embed = nn.Embedding(self.vocab_size, self.embed_size)
        self.out_embed = nn.Embedding(self.vocab_size, self.embed_size)
        
    def forward(self, input_labels, pos_labels, neg_labels):
        ''' input_labels: center words, [batch_size]
            pos_labels: positive words, [batch_size, (window_size * 2)]
            neg_labels：negative words, [batch_size, (window_size * 2 * K)]
            
            return: loss, [batch_size]
        '''
        input_embedding = self.in_embed(input_labels) # [batch_size, embed_size]
        pos_embedding = self.out_embed(pos_labels)# [batch_size, (window * 2), embed_size]
        neg_embedding = self.out_embed(neg_labels) # [batch_size, (window * 2 * K), embed_size]
        
        input_embedding = input_embedding.unsqueeze(2) # [batch_size, embed_size, 1]
        
        pos_dot = torch.bmm(pos_embedding, input_embedding) # [batch_size, (window * 2), 1]
        pos_dot = pos_dot.squeeze(2) # [batch_size, (window * 2)]
        
        neg_dot = torch.bmm(neg_embedding, -input_embedding) # [batch_size, (window * 2 * K), 1]
        neg_dot = neg_dot.squeeze(2) # batch_size, (window * 2 * K)]
        
        log_pos = F.logsigmoid(pos_dot).sum(1) # .sum()结果只为一个数，.sum(1)结果是一维的张量
        log_neg = F.logsigmoid(neg_dot).sum(1)
        
        loss = log_pos + log_neg
        
        return -loss
    
    def input_embedding(self):
        return self.in_embed.weight.data.cpu().numpy()

def train():
    dataset = WordEmbeddingDataset(text, word2idx, idx2word, word_freqs, word_counts)
    dataloader = tud.DataLoader(dataset, batch_size, shuffle=True)

    model = EmbeddingModel(vocab_size, EMBEDDING_SIZE)

    optimizer = SGD(model.parameters(), lr)

    # cuda=torch.cuda.is_available() # 判断gpu是否可用
    # if cuda:
    #     print(cuda)
    #     model=model.cuda()
    model=model.to(device)

    for epoch in range(epochs):
        for step, (input_labels, pos_labels, neg_labels) in enumerate(dataloader):
            input_labels = input_labels.long()
            pos_labels = pos_labels.long()
            neg_labels = neg_labels.long()

            # if cuda:
            #     input_labels = input_labels.cuda()
            #     pos_labels = pos_labels.cuda()
            #     neg_labels = neg_labels.cuda()
            input_labels = input_labels.to(device)
            pos_labels = pos_labels.to(device)
            neg_labels = neg_labels.to(device)

            optimizer.zero_grad()   #梯度清零
            loss = model(input_labels, pos_labels, neg_labels).mean()   #梯度清零
            loss.backward() #反向传播
            optimizer.step()    #梯度更新

            if step % 100 == 0:
                print('epoch', epoch, 'iteration', step, loss.item())

    embedding_weights = model.input_embedding()
    print(embedding_weights)
    print(len(embedding_weights))
    print(embedding_weights[word2idx['expr']])
    print(len(embedding_weights[word2idx['expr']]))
    np.save('model/embedding-{}'.format(EMBEDDING_SIZE), embedding_weights)
    torch.save(model.state_dict(), "model/embedding-{}.th".format(EMBEDDING_SIZE))

# def find_nearest(word):
#     index = word2idx[word]
#     embedding = embedding_weights[index]
#     cos_dis = np.array([scipy.spatial.distance.cosine(e, embedding) for e in embedding_weights])
#     return [idx2word[i] for i in cos_dis.argsort()[:10]]

# for word in ["expr", "var", "Function", "main"]:
#     print(word, find_nearest(word))

