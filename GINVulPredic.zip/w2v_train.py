from src.word2vec.word2vec import train

# word2vec模型训练
train()